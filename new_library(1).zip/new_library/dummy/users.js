data = [
    {
        username: "Alaa",
        password: "12345"
    },
    {
        username: "super_admin",
        password: "secret"
    },
    {
        username: "Ali",
        password: "1234"
    }
];