data = [
    { 
        id: 1,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 2,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 3,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 4,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 5,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 6,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 7,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 8,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 9,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    },
    { 
        id: 10,
        title: "The standard Lorem Ipsum passage",
        url: "../assets/image/images.jpg",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud "
    }
];