function logout()
{
    localStorage.clear();
    window.open("login.html", '_self');


}