function User(username, password){
    this.username = username;
    this.password = password;
    
}